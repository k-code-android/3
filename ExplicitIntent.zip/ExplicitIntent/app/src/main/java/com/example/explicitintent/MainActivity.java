package com.example.explicitintent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;

public class MainActivity extends AppCompatActivity {
    String tag="My First Activity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide(); // hide the title bar
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN); //show the activity in full screen
        setContentView(R.layout.activity_main);


        Log.d(tag,"I am running onCreate()");
    }
    public void callActivity2(View v)
    {
        Intent activity2 = new Intent(this,Activity2.class);
        activity2.putExtra("message","This is test");
        this.startActivity(activity2);

    }
    public void onStart() {

        super.onStart();
        Log.d(tag,"I am running onStart()");
    }

    public void onRestart() {

        super.onRestart();
        Log.d(tag,"I am running onRestart()");

    }
    public void onResume() {

        super.onResume();
        Log.d(tag,"I am running onResume()");
    }
    public void onPause() {

        super.onPause();
        Log.d(tag,"I am running onPause()");
    }
    public void onStop() {

        super.onStop();
        Log.d(tag,"I am running onStop()");

    }
    public void onDestroy() {

        super.onDestroy();
        Log.d(tag,"I am running onDestroy()");

    }

}
